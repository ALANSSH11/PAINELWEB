<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ative seu BOT</title>
</head>
<body>

<center>

	<h1>CONFIGURE SEU BOT</h1>
	<p>Edite o arquivo <b>TlgTools.php</b> para ativar seu bot
	<ul>
	<li>MercadoPago Access Token</li>
	<li>BOT TOKEN</li>
	<li>VALOR DO LOGIN</li>
	<li>BOT USER</li>
	<li>IP/DOMINIO DA VPS</li>
	<li>IP/DOMINIO DA SSH</li>
	<li>SENHA ROOT DA VPS</li>
	<li>TEMPO DO TESTE</li>
	<li>ID DO CANAL TELEGRAM</li>
	<li>USUARIO DO SUPORTE</li>
	<li>NOME DO APK</li>
	</ul>

	<h1>APK INFO</h1>
	<p>Para editar o apk, basta adiciona-lo na pasta <a href="apk/">apk</a></p>
	
	<h1>ATIVE SEU BOT</h1>
	<p>Já configurou seu bot ? ative ele agora clicando <a href="bot.php">aqui</a></p>

	<br><p>
		Após inserir todos os dados você deve instalar os ultimos recursos clique abaixo<br>
		<p><a href="getall.php?install=1">Recurso 1</a></p>
        <p><a href="getall.php?install=2">Recurso 2</a></p>
	</ul>


</center>

</body>
</html>