<section id="multiple-column-form">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">UPLOAD DE APPS</h4>
					<a class="text-bold-800 grey darken-2" href="../apps" target="_blank">CLICK AQUI PARA IR PARA A LOJA DE APPS</a></span>
                </div>
                <div class="card-body">
<center><p class="px-0"><b>AQUI FAZ UPLOAD DO APP 1.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeUpload.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
	   <p>
				</p>
    </form>
</div>
<center><p class="px-0"><b>AQUI FAZ UPLOAD DO APP 2.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeUpload2.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
	   <p>
				</p>		
    </form>
</br>	
<center><p class="px-0"><b>AQUI FAZ UPLOAD DO APP 3.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeUpload3.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>	
                </div>
            </div>
        </div>
    </div>	
</section>